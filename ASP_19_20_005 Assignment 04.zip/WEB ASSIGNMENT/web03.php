<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>about</title>
	<link rel="stylesheet" href="stylep.css">
<style>
</style>
</head>
<body>
	<div class="mvv-container">
		<div class="mvv-block">
			<div class="image">
				<img src="project1.jpg" alt="">
			</div>
			<div class="content">
				<h5>SAMPLE 01</h5>
				<p style="font-size:20px;">
				  Design a poem for your soulmate for your upcoming ceremony(Birthdays,Anniversary). Go with our So This Is Love design or shop our entire items .If you are interested on me then You can write a poem from me for your soulmate and enjoy an another feelling.
				</p>
			</div>
		</div>
		<div class="mvv-block">
			<div class="image">
				<img src="project2.jpg" alt="">
			</div>
			<div class="content">
				<h5>SAMPLE 02</h5>
				<p style="font-size:20px;">
					Design a poem for you or for the person who closed you. Surprise them their special days with unexpected gifts.
				</p>
			</div>
		</div>
		<div class="mvv-block">
			<div class="image">
				<img src="project3.jpg" alt="">
			</div>
			<div class="content">
				<h5>SAMPLE 03</h5>
				<p style="font-size:20px;">
					If you are in any kind of poem compitition, you can get help from me. Also If you want to learn how to write a poem,You can contact me.

				</p>
				<br><br>
				<button onclick="document.location='new.html'">Slide Show</button><br><br>
				<button onclick="document.location='newww.html'">Show More</button>
			</div>
		</div>

	</div>
	
</body>
</html>