<!DOCTYPE html>
<html lang="en">
<head>
	<title>about</title>
	<link rel="stylesheet" href="stylea.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
	<section id="about">
		<div class="about-1">
			<h1><b>About Us</b></h1><br><br>
			<p style="font-family:cursive;"><b>BREATHE IN EXPERIENCE,BREATHE OUT POETRY</b></p>
		</div>
		<div id="about-2">
			<div class="content-box-lg">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="about-item text-center">
							<i class="fa fa-book"></i>
							<h3>MISSION</h3>
							<hr>
							<p>Make a choice for poetry people who are not interesting them and provide 
							our services as well as better.</p>
						</div>
					</div>
					<div class="col-md-4">
							<div class="about-item text-center">
							<i class="fa fa-globe"></i>
							<h3>VISSION</h3>
							<hr>
							<p>It's not what you look at that matters.
							It's what you see.
						Try to see a beautiful in everything.</p>
						</div>
					</div>
					<div class="col-md-4">
							<div class="about-item text-center">
							<i class="fa fa-pencil"></i>
							<h3>ME</h3>
							<hr>
							<p>I love to supply the poems as the pain killers</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</section>
	<button onclick="document.location='new2.html'">Continue</button>

</body>
</html>